const { app, action, core, constants } = require("photoshop");
const { entrypoints } = require("uxp");

const state = {
  fonts: new Map(),
  selectedFont: null,
  navigationIndex: -1,
  documentId: null,
  busy: false
};

const $ = (id) => document.getElementById(id);

function setStatus(message, isError = false) {
  $("status").textContent = message;
  $("status").classList.toggle("error", isError);
}

function setBusy(busy) {
  state.busy = busy;
  $("refreshButton").disabled = busy;
  updateControls();
}

function updateControls() {
  const record = state.selectedFont ? state.fonts.get(state.selectedFont) : null;
  const canNavigate = !state.busy && record && record.layers.length > 0;
  $("previousButton").disabled = !canNavigate;
  $("nextButton").disabled = !canNavigate;
  $("replaceButton").disabled = !canNavigate || !$("targetFont").value;
  $("targetFont").disabled = state.busy || $("targetFont").options.length <= 1;
}

function collectLayers(layers, result = []) {
  for (const layer of layers) {
    result.push(layer);
    if (layer.layers && layer.layers.length) collectLayers(layer.layers, result);
  }
  return result;
}

async function getTextDescriptor(layerId) {
  const result = await action.batchPlay([{
    _obj: "get",
    _target: [
      { _ref: "property", _property: "textKey" },
      { _ref: "layer", _id: layerId }
    ],
    _options: { dialogOptions: "dontDisplay" }
  }], {});
  return result[0] && result[0].textKey;
}

function fontFromStyle(style) {
  if (!style) return null;
  const postScriptName = style.fontPostScriptName || "";
  const family = style.fontName || postScriptName;
  const fontStyle = style.fontStyleName || "";
  if (!postScriptName && !family) return null;
  return { postScriptName: postScriptName || family, family, style: fontStyle };
}

function fontsInTextDescriptor(text) {
  const found = new Map();
  const add = (style) => {
    const font = fontFromStyle(style);
    if (font) found.set(font.postScriptName, font);
  };
  add(text && text.textStyle);
  for (const range of (text && text.textStyleRange) || []) add(range.textStyle);
  return [...found.values()];
}

async function scanDocument() {
  if (state.busy) return;
  setBusy(true);
  try {
    if (!app.documents.length) throw new Error("当前没有打开的 Photoshop 文档。");
    const doc = app.activeDocument;
    state.documentId = doc.id;
    state.fonts.clear();
    state.selectedFont = null;
    state.navigationIndex = -1;

    const textLayers = collectLayers(doc.layers).filter(layer =>
      layer.kind === constants.LayerKind.TEXT || layer.kind === "textLayer"
    );

    for (const layer of textLayers) {
      try {
        const text = await getTextDescriptor(layer.id);
        for (const font of fontsInTextDescriptor(text)) {
          if (!state.fonts.has(font.postScriptName)) {
            state.fonts.set(font.postScriptName, { ...font, layers: [] });
          }
          state.fonts.get(font.postScriptName).layers.push({ id: layer.id, name: layer.name });
        }
      } catch (error) {
        console.warn(`无法读取文字图层 ${layer.name}:`, error);
      }
    }

    renderFontList();
    const count = state.fonts.size;
    setStatus(`已扫描 ${textLayers.length} 个文字图层，发现 ${count} 种字体。`);
  } catch (error) {
    state.fonts.clear();
    renderFontList();
    setStatus(error.message || String(error), true);
  } finally {
    setBusy(false);
  }
}

function renderFontList() {
  const list = $("fontList");
  list.innerHTML = "";
  const records = [...state.fonts.values()].sort((a, b) =>
    `${a.family} ${a.style}`.localeCompare(`${b.family} ${b.style}`)
  );
  $("fontCount").textContent = String(records.length);

  if (!records.length) {
    const empty = document.createElement("div");
    empty.className = "empty";
    empty.textContent = "未发现使用字体的文字图层";
    list.appendChild(empty);
  }

  for (const record of records) {
    const button = document.createElement("button");
    button.className = "font-item";
    button.dataset.font = record.postScriptName;
    const label = document.createElement("span");
    label.className = "font-main";
    label.textContent = `${record.family}${record.style ? ` · ${record.style}` : ""}`;
    const usage = document.createElement("span");
    usage.className = "font-usage";
    usage.textContent = `${record.layers.length} 层`;
    button.append(label, usage);
    button.addEventListener("click", () => chooseFont(record.postScriptName));
    list.appendChild(button);
  }
  updateSelectionInfo();
}

function chooseFont(postScriptName) {
  state.selectedFont = postScriptName;
  state.navigationIndex = -1;
  document.querySelectorAll(".font-item").forEach(item =>
    item.classList.toggle("selected", item.dataset.font === postScriptName)
  );
  updateSelectionInfo();
}

function updateSelectionInfo() {
  const record = state.selectedFont ? state.fonts.get(state.selectedFont) : null;
  if (!record) {
    $("selectionInfo").textContent = "请先选择一种字体";
  } else if (state.navigationIndex < 0) {
    $("selectionInfo").textContent = `已选：${record.family}（${record.layers.length} 个图层）`;
  } else {
    const layer = record.layers[state.navigationIndex];
    $("selectionInfo").textContent = `${state.navigationIndex + 1} / ${record.layers.length} · ${layer.name}`;
  }
  updateControls();
}

async function navigate(direction) {
  const record = state.fonts.get(state.selectedFont);
  if (!record || state.busy) return;
  if (!app.documents.length || app.activeDocument.id !== state.documentId) {
    setStatus("活动文档已改变，请先刷新。", true);
    return;
  }
  const total = record.layers.length;
  state.navigationIndex = (state.navigationIndex + direction + total) % total;
  const target = record.layers[state.navigationIndex];
  setBusy(true);
  try {
    await core.executeAsModal(async () => {
      await action.batchPlay([{
        _obj: "select",
        _target: [{ _ref: "layer", _id: target.id }],
        makeVisible: false,
        _options: { dialogOptions: "dontDisplay" }
      }], {});
    }, { commandName: "定位字体图层" });
    setStatus(`已选中图层：${target.name}`);
  } catch (error) {
    setStatus(`无法选中图层：${error.message || error}`, true);
  } finally {
    setBusy(false);
    updateSelectionInfo();
  }
}

function replaceFontInDescriptor(text, sourceName, target) {
  let changed = false;
  const update = (style) => {
    if (!style || style.fontPostScriptName !== sourceName) return;
    style.fontPostScriptName = target.postScriptName;
    style.fontName = target.family;
    style.fontStyleName = target.style;
    changed = true;
  };
  update(text.textStyle);
  for (const range of text.textStyleRange || []) update(range.textStyle);
  return changed;
}

async function replaceSelectedFont() {
  const source = state.fonts.get(state.selectedFont);
  const targetName = $("targetFont").value;
  if (!source || !targetName || state.busy) return;
  if (targetName === source.postScriptName) {
    setStatus("源字体和目标字体相同，无需替换。", true);
    return;
  }
  const targetSelect = $("targetFont");
  const targetOption = targetSelect.options[targetSelect.selectedIndex];
  const target = {
    postScriptName: targetName,
    family: targetOption.dataset.family || targetName,
    style: targetOption.dataset.style || "Regular"
  };
  if (!app.documents.length || app.activeDocument.id !== state.documentId) {
    setStatus("活动文档已改变，请先刷新。", true);
    return;
  }

  setBusy(true);
  let changedLayers = 0;
  try {
    await core.executeAsModal(async (executionContext) => {
      const suspension = await executionContext.hostControl.suspendHistory({
        documentID: state.documentId,
        name: `替换字体：${source.family} → ${target.family}`
      });
      let commit = false;
      try {
        for (const layer of source.layers) {
          const text = await getTextDescriptor(layer.id);
          if (!text || !replaceFontInDescriptor(text, source.postScriptName, target)) continue;
          await action.batchPlay([{
            _obj: "set",
            _target: [{ _ref: "layer", _id: layer.id }],
            to: { _obj: "textLayer", ...text },
            _options: { dialogOptions: "dontDisplay" }
          }], {});
          changedLayers++;
        }
        commit = true;
      } finally {
        await executionContext.hostControl.resumeHistory(suspension, commit);
      }
    }, { commandName: "批量替换字体" });
    setBusy(false);
    await scanDocument();
    setStatus(`替换完成：已修改 ${changedLayers} 个文字图层；字体列表已刷新。`);
  } catch (error) {
    setStatus(`替换失败：${error.message || error}`, true);
    setBusy(false);
  }
}

async function loadInstalledFonts() {
  const select = $("targetFont");
  try {
    const result = await action.batchPlay([{
      _obj: "get",
      _target: [
        { _ref: "property", _property: "fontList" },
        { _ref: "application", _enum: "ordinal", _value: "targetEnum" }
      ],
      _options: { dialogOptions: "dontDisplay" }
    }], {});
    const fonts = (result[0] && result[0].fontList) || [];
    select.innerHTML = '<option value="">请选择目标字体…</option>';
    fonts
      .filter(font => font.fontPostScriptName)
      .sort((a, b) => `${a.fontName} ${a.fontStyleName}`.localeCompare(`${b.fontName} ${b.fontStyleName}`))
      .forEach(font => {
        const option = document.createElement("option");
        option.value = font.fontPostScriptName;
        option.dataset.family = font.fontName || font.fontPostScriptName;
        option.dataset.style = font.fontStyleName || "Regular";
        option.textContent = `${option.dataset.family} · ${option.dataset.style}`;
        select.appendChild(option);
      });
  } catch (error) {
    select.innerHTML = '<option value="">无法读取已安装字体</option>';
    console.error(error);
  }
  updateControls();
}

function wireEvents() {
  $("refreshButton").addEventListener("click", scanDocument);
  $("previousButton").addEventListener("click", () => navigate(-1));
  $("nextButton").addEventListener("click", () => navigate(1));
  $("replaceButton").addEventListener("click", replaceSelectedFont);
  $("targetFont").addEventListener("change", updateControls);
}

entrypoints.setup({
  panels: {
    fontNavigatorPanel: {
      show() {}
    }
  }
});

document.addEventListener("DOMContentLoaded", async () => {
  wireEvents();
  await loadInstalledFonts();
  await scanDocument();
});
